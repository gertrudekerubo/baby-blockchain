# baby-blockchain
to launch run:
go run main.go


Block chain Land/Property Registry

Description Land/properties sale and ownership is a very time-consuming process involving many middlemen, thus increasing chances of fraud. These problems can subsequently be prevented by use of Block chain technology which I will demonstrate within this project.

Overview The system will entail all activities from ownership, transfer, land and construction permits.

System content (system boundaries) • Land sale • Land ownership • Land rates of the land in question • Construction permits of the land in question Interactions • Governments and involved municipalities • Tax and law institutes and bodies in case of queries • Private companies • Potential buyers/sellers

Product features • Elimination third parties therefore faster process • Reduce fraud • Easier audits and levies collection

i will start my implementation with a simple bank to get an understanding of how to implement the above project
